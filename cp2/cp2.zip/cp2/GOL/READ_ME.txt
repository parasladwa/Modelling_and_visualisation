

<run> <GOL.py> <N> <method>

N is system size

method {random, oscillator, glider}

if glider is run a plot of COM and Velocity will follow animation
images & datafiles stored within.
