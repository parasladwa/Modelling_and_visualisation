

All simulation code written within SIRS.py

run in CLI with argparser


for more information:
<run> <SIRS.py> -h 


datafiles stored within

to view plots use argparser and associated arguments to visualise



NB: 

y axis on certain plots are seemingly of wrong magnitude
t.py is an attempt to artificially alter these values.
(essentially t.py is an identical copy of SIRS.py with scale factors)
