cp1.py is all the python script



TO RUN VISUALISATION:

	run cp1.py, instructions in command line
	note : depending on ide execution may differ, eg spyder uses "%run"
		may need to swap this






kawasaki_temp.txt and glauber_50_1000.txt are the raw data files

analysis leads to all_results.txt

kawasaki_temp.txt is not full-scale simulation, didn't have time to run simulation,

images are plots as titled.

